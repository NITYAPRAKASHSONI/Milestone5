
package com.mindtree.springbootbackendangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBackendAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBackendAngularApplication.class, args);
	}

}
